-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_comment`
--

DROP TABLE IF EXISTS `tb_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_comment` (
  `comment_no` int NOT NULL AUTO_INCREMENT COMMENT '댓글 번호',
  `feed_no` int NOT NULL COMMENT '피드 번호',
  `parent_comment_no` int DEFAULT NULL COMMENT '원댓글 번호',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '작성 시각',
  `is_modified` bit(1) DEFAULT b'0' COMMENT '수정 여부',
  `is_removed` bit(1) DEFAULT b'0' COMMENT '삭제 여부',
  `member_no` int NOT NULL COMMENT '유저 번호',
  `content` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`comment_no`),
  KEY `fk_tb_comment_tb_feed1_idx` (`feed_no`),
  KEY `fk_tb_comment_tb_comment1_idx` (`parent_comment_no`),
  KEY `fk_tb_comment_tb_user1_idx` (`member_no`),
  CONSTRAINT `fk_tb_comment_tb_comment1` FOREIGN KEY (`parent_comment_no`) REFERENCES `tb_comment` (`comment_no`),
  CONSTRAINT `fk_tb_comment_tb_feed1` FOREIGN KEY (`feed_no`) REFERENCES `tb_feed` (`feed_no`) ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_comment_tb_user1` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_comment`
--

LOCK TABLES `tb_comment` WRITE;
/*!40000 ALTER TABLE `tb_comment` DISABLE KEYS */;
INSERT INTO `tb_comment` VALUES (152,173,NULL,'2022-08-18 08:19:09',_binary '\0',_binary '\0',1820,'저도 감동적이에요 ㅠㅠ'),(153,173,NULL,'2022-08-18 08:20:27',_binary '\0',_binary '\0',1816,'진짜 귀호강 했습니다.. ><'),(154,173,NULL,'2022-08-18 08:21:17',_binary '\0',_binary '\0',1818,'내친구 최고다!!'),(155,173,153,'2022-08-18 08:21:31',_binary '\0',_binary '\0',1818,'저도요 ㅠㅠ'),(156,173,152,'2022-08-18 08:21:57',_binary '\0',_binary '\0',1818,'감동감동.. ㅜㅜ'),(157,173,NULL,'2022-08-18 08:24:25',_binary '\0',_binary '\0',1824,'최고의 음색이었어요!'),(158,173,NULL,'2022-08-18 08:25:35',_binary '\0',_binary '',1819,'감사합니다!'),(159,173,NULL,'2022-08-18 08:27:55',_binary '',_binary '',1819,'모두들 공연 보러 와주셔서 정말 감사합니다! ㅜㅜ 앞으로 더 열심히 하겠습니다!!'),(160,173,153,'2022-08-18 08:28:24',_binary '',_binary '\0',1819,'관심 너무나도 감사드려요:)'),(161,173,157,'2022-08-18 08:28:47',_binary '\0',_binary '',1819,'칭찬 감사합니닷!!'),(162,175,NULL,'2022-08-18 14:19:33',_binary '\0',_binary '\0',1820,'좋아좋아'),(163,175,162,'2022-08-18 14:21:21',_binary '\0',_binary '\0',1820,'??'),(164,172,NULL,'2022-08-18 14:53:57',_binary '\0',_binary '\0',1822,'댓글을 작성해 소통할 수 있습니다'),(165,176,NULL,'2022-08-18 15:44:37',_binary '\0',_binary '',1820,'짱짱'),(166,167,NULL,'2022-08-19 01:43:06',_binary '\0',_binary '\0',1822,'재밌어요');
/*!40000 ALTER TABLE `tb_comment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:42
