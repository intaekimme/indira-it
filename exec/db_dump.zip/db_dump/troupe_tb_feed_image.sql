-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_feed_image`
--

DROP TABLE IF EXISTS `tb_feed_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_feed_image` (
  `image_no` int NOT NULL AUTO_INCREMENT,
  `feed_no` int NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`image_no`),
  KEY `fk_tb_feed_image_tb_feed1_idx` (`feed_no`),
  CONSTRAINT `fk_tb_feed_image_tb_feed1` FOREIGN KEY (`feed_no`) REFERENCES `tb_feed` (`feed_no`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=544 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_feed_image`
--

LOCK TABLES `tb_feed_image` WRITE;
/*!40000 ALTER TABLE `tb_feed_image` DISABLE KEYS */;
INSERT INTO `tb_feed_image` VALUES (516,162,'feed/e9081950-bd6b-4405-ad83-3bde3699375dpenguin.png'),(517,163,'feed/f90c8bcd-b038-495c-9956-b404a5a22d8a라이브클럽데이.jpg'),(518,164,'feed/f564a797-69ca-44e0-beb5-ed37c08d7a0c까데호.jpg'),(519,164,'feed/bd76fc09-47ce-453f-94a3-e239c5872d58당신께.jfif'),(520,165,'feed/7bebda0d-ce56-4786-bef8-8e1d9af9379c더 발룬티어스.jpg'),(521,166,'feed/9425322e-6514-416a-8d47-499a97ce0adc햄릿 연극.jpg'),(522,167,'feed/226e8811-4dc9-40c8-94fe-a4d9ad667da1edinburgh_festival_tickets.jpg'),(523,167,'feed/692bc8d9-f338-41fd-b6c5-4d0bdc5945ff연극2.jpg'),(524,167,'feed/2bec988a-9196-419d-b204-5fe8451aa132봄날의 햇살.jpg'),(525,168,'feed/6ad23ac8-26ab-42eb-b4ec-56167f327747적재.jpg'),(526,169,'feed/92f2fd81-2ff1-4b7c-a765-9f13e3de2fb6라이프 사진전.png'),(527,170,'feed/9004b555-1a04-4934-a49a-1d5f26ee1f2e백조의 호수.jpg'),(528,171,'feed/0a3a3f72-1357-4851-9525-82a336e6fe4a미스사이공.jpg'),(529,172,'feed/449f4914-a879-4270-a126-fd69af416866캣츠 2.jpg'),(530,172,'feed/38baa1fd-7b75-4abc-9864-a4f08d189c93캣츠 3.jpg'),(531,172,'feed/a8d7e398-7fb1-4a15-ac9d-7c0c51b1ab25캣츠.jpg'),(532,173,'feed/3f263c2b-1d45-44fb-9054-c20086cb9aaf라이브클럽데이.jpg'),(533,174,'feed/8a4271d4-20fe-432a-8112-50e6afcd89b4적재.jpg'),(534,175,'feed/82bd64de-7e52-4cf6-b0a4-04d640764f1311.gif'),(535,175,'feed/4545f2b5-951d-40e8-baf2-2e70d6704228forest2.gif'),(536,176,'feed/7838ba7a-e73b-49ca-b0c2-6d73e2db51f42019_10_18_T58680122_boardNormalReg_IMG_4201.gif'),(537,176,'feed/ad98b864-4d15-4e01-9423-d6f8e1cde1b22019_10_18_T58680122_boardNormalReg_IMG_4210.gif'),(538,176,'feed/91f44f7d-9e4c-439d-8d7f-36f6766bcc112019_10_18_T58680122_boardNormalReg_IMG_4207.gif'),(539,176,'feed/0ffa379c-5939-47b2-a025-e8f5ff1c435f2019_10_18_T58680122_boardNormalReg_IMG_4204.jpg'),(540,177,'feed/2ed5a939-1a78-4fc9-a096-e910e2975e0d헤어스프레이8.JPG'),(541,177,'feed/1b330f94-38e7-402b-820a-9261d5b47527헤어스프레이9.JPG'),(542,177,'feed/bde9807c-8542-4f0e-94f6-04260373cf6a헤어스프레이10.JPG'),(543,178,'feed/de8971c5-697c-474f-9447-d68e7ef8d19fcute2.jpg');
/*!40000 ALTER TABLE `tb_feed_image` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:31
