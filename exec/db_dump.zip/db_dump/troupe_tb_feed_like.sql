-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_feed_like`
--

DROP TABLE IF EXISTS `tb_feed_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_feed_like` (
  `feed_like_no` int NOT NULL AUTO_INCREMENT,
  `member_no` int NOT NULL COMMENT '유저번호',
  `feed_no` int NOT NULL COMMENT '피드 번호',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '좋아요 누른 시각',
  `is_deleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`feed_like_no`),
  KEY `fk_tb_feed_like_tb_feed1_idx` (`feed_no`),
  KEY `fk_tb_feed_like_tb_user10` (`member_no`),
  CONSTRAINT `fk_tb_feed_like_tb_feed10` FOREIGN KEY (`feed_no`) REFERENCES `tb_feed` (`feed_no`) ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_feed_like_tb_user10` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_feed_like`
--

LOCK TABLES `tb_feed_like` WRITE;
/*!40000 ALTER TABLE `tb_feed_like` DISABLE KEYS */;
INSERT INTO `tb_feed_like` VALUES (177,1816,162,'2022-08-19 00:54:51',_binary '\0'),(178,1819,171,'2022-08-18 06:09:45',_binary '\0'),(179,1819,170,'2022-08-18 05:12:46',_binary '\0'),(180,1819,168,'2022-08-18 06:09:56',_binary ''),(181,1819,169,'2022-08-18 05:12:52',_binary '\0'),(182,1819,164,'2022-08-18 06:09:52',_binary '\0'),(183,1819,163,'2022-08-18 06:09:53',_binary '\0'),(184,1819,165,'2022-08-18 05:12:58',_binary '\0'),(185,1819,162,'2022-08-18 05:13:00',_binary '\0'),(186,1816,171,'2022-08-18 05:45:22',_binary ''),(187,1819,173,'2022-08-18 06:06:23',_binary '\0'),(188,1819,172,'2022-08-18 06:06:28',_binary '\0'),(189,1819,166,'2022-08-18 06:06:31',_binary '\0'),(190,1819,167,'2022-08-18 06:06:37',_binary '\0'),(191,1819,174,'2022-08-18 06:12:16',_binary '\0'),(192,1816,173,'2022-08-18 08:20:40',_binary '\0'),(193,1824,174,'2022-08-18 08:23:00',_binary '\0'),(194,1824,173,'2022-08-18 08:23:03',_binary '\0'),(195,1824,172,'2022-08-18 08:23:03',_binary '\0'),(196,1824,169,'2022-08-18 08:23:06',_binary '\0'),(197,1824,170,'2022-08-18 08:23:07',_binary '\0'),(198,1824,171,'2022-08-18 08:23:09',_binary '\0'),(199,1824,165,'2022-08-18 08:23:11',_binary '\0'),(200,1824,166,'2022-08-18 08:23:21',_binary ''),(201,1824,167,'2022-08-18 08:23:23',_binary ''),(202,1824,164,'2022-08-18 08:23:15',_binary '\0'),(203,1824,163,'2022-08-18 08:23:16',_binary '\0'),(204,1824,162,'2022-08-18 08:23:17',_binary '\0'),(205,1818,170,'2022-08-18 08:24:00',_binary '\0'),(206,1820,174,'2022-08-18 08:48:03',_binary '\0'),(207,1820,172,'2022-08-18 08:48:04',_binary '\0'),(208,1820,170,'2022-08-18 08:48:05',_binary '\0'),(209,1820,166,'2022-08-18 08:48:07',_binary '\0'),(210,1820,167,'2022-08-18 08:50:35',_binary '\0'),(211,1820,163,'2022-08-18 08:50:36',_binary '\0'),(212,1820,165,'2022-08-18 08:50:37',_binary '\0'),(213,1820,175,'2022-08-18 13:07:08',_binary '\0'),(214,1816,172,'2022-08-19 00:54:28',_binary '\0'),(215,1816,174,'2022-08-19 00:54:30',_binary '\0'),(216,1816,178,'2022-08-19 00:54:31',_binary '\0'),(217,1816,177,'2022-08-19 00:54:31',_binary '\0'),(218,1816,176,'2022-08-19 00:54:33',_binary '\0'),(219,1816,169,'2022-08-19 00:54:38',_binary '\0'),(220,1816,170,'2022-08-19 00:54:40',_binary '\0'),(221,1816,166,'2022-08-19 00:54:44',_binary '\0'),(222,1822,167,'2022-08-19 01:43:08',_binary '\0');
/*!40000 ALTER TABLE `tb_feed_like` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:40
