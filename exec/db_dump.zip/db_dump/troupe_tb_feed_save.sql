-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_feed_save`
--

DROP TABLE IF EXISTS `tb_feed_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_feed_save` (
  `feed_save_no` int NOT NULL AUTO_INCREMENT COMMENT 'primary key',
  `member_no` int NOT NULL COMMENT '유저번호',
  `feed_no` int NOT NULL COMMENT '피드 번호',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '저장한 시각',
  `is_deleted` bit(1) DEFAULT b'0',
  PRIMARY KEY (`feed_save_no`),
  KEY `fk_tb_feed_like_tb_feed1_idx` (`feed_no`),
  KEY `fk_tb_feed_like_tb_user1` (`member_no`),
  CONSTRAINT `fk_tb_feed_like_tb_feed1` FOREIGN KEY (`feed_no`) REFERENCES `tb_feed` (`feed_no`) ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_feed_like_tb_user1` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_feed_save`
--

LOCK TABLES `tb_feed_save` WRITE;
/*!40000 ALTER TABLE `tb_feed_save` DISABLE KEYS */;
INSERT INTO `tb_feed_save` VALUES (147,1816,162,'2022-08-18 04:58:06',_binary ''),(148,1819,168,'2022-08-18 06:09:56',_binary ''),(149,1819,169,'2022-08-18 05:12:53',_binary '\0'),(150,1819,164,'2022-08-18 06:09:53',_binary '\0'),(151,1819,163,'2022-08-18 05:12:57',_binary '\0'),(152,1819,165,'2022-08-18 05:12:59',_binary '\0'),(153,1819,162,'2022-08-18 05:13:00',_binary '\0'),(154,1819,173,'2022-08-18 06:06:25',_binary '\0'),(155,1819,171,'2022-08-18 06:06:26',_binary '\0'),(156,1819,172,'2022-08-18 06:09:43',_binary '\0'),(157,1819,166,'2022-08-18 06:06:32',_binary '\0'),(158,1819,167,'2022-08-18 06:09:51',_binary '\0'),(159,1819,174,'2022-08-18 06:12:17',_binary '\0'),(160,1816,173,'2022-08-18 08:20:41',_binary '\0'),(161,1824,174,'2022-08-18 08:22:59',_binary '\0'),(162,1824,173,'2022-08-18 08:23:02',_binary '\0'),(163,1824,172,'2022-08-18 08:23:04',_binary '\0'),(164,1824,169,'2022-08-18 08:23:22',_binary ''),(165,1824,170,'2022-08-18 08:23:07',_binary '\0'),(166,1824,171,'2022-08-18 08:23:08',_binary '\0'),(167,1824,165,'2022-08-18 08:23:11',_binary '\0'),(168,1824,166,'2022-08-18 08:23:21',_binary ''),(169,1824,167,'2022-08-18 08:23:13',_binary '\0'),(170,1824,164,'2022-08-18 08:23:15',_binary '\0'),(171,1824,163,'2022-08-18 08:23:16',_binary '\0'),(172,1824,162,'2022-08-18 08:23:18',_binary '\0'),(173,1818,170,'2022-08-18 08:23:55',_binary '\0'),(174,1820,174,'2022-08-18 08:58:53',_binary '\0'),(175,1820,172,'2022-08-18 08:58:53',_binary '\0'),(176,1820,171,'2022-08-18 08:58:54',_binary '\0'),(177,1820,166,'2022-08-18 08:58:56',_binary '\0'),(178,1820,167,'2022-08-18 08:58:56',_binary '\0'),(179,1822,175,'2022-08-18 09:40:57',_binary '\0'),(180,1822,173,'2022-08-18 09:40:58',_binary '\0'),(181,1822,171,'2022-08-18 09:41:00',_binary '\0'),(184,1820,175,'2022-08-18 13:07:19',_binary ''),(185,1822,176,'2022-08-18 14:53:38',_binary '\0'),(186,1822,174,'2022-08-18 14:53:39',_binary '\0'),(187,1816,166,'2022-08-19 00:54:45',_binary '\0'),(188,1816,178,'2022-08-19 00:55:06',_binary '\0'),(189,1822,167,'2022-08-19 01:43:11',_binary '\0'),(190,1822,165,'2022-08-19 01:43:12',_binary '\0'),(191,1822,169,'2022-08-19 01:43:13',_binary '\0');
/*!40000 ALTER TABLE `tb_feed_save` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:40
