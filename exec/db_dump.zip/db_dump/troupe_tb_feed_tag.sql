-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_feed_tag`
--

DROP TABLE IF EXISTS `tb_feed_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_feed_tag` (
  `feed_tag_no` int NOT NULL AUTO_INCREMENT COMMENT 'primary key',
  `tag_no` int NOT NULL COMMENT '태그번호',
  `feed_no` int NOT NULL COMMENT '피드번호',
  PRIMARY KEY (`feed_tag_no`),
  KEY `fk_tb_feedtag_tb_tag1_idx` (`tag_no`),
  KEY `fk_tb_feedtag_tb_feed1` (`feed_no`),
  CONSTRAINT `fk_tb_feedtag_tb_feed1` FOREIGN KEY (`feed_no`) REFERENCES `tb_feed` (`feed_no`) ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_feedtag_tb_tag1` FOREIGN KEY (`tag_no`) REFERENCES `tb_tag` (`tag_no`)
) ENGINE=InnoDB AUTO_INCREMENT=344 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_feed_tag`
--

LOCK TABLES `tb_feed_tag` WRITE;
/*!40000 ALTER TABLE `tb_feed_tag` DISABLE KEYS */;
INSERT INTO `tb_feed_tag` VALUES (284,188,162),(285,189,162),(286,190,163),(287,191,163),(288,192,163),(289,193,163),(290,194,164),(291,195,164),(292,196,164),(293,197,165),(294,198,165),(295,199,165),(296,200,166),(297,201,166),(298,202,166),(299,193,166),(300,203,167),(301,202,167),(302,204,167),(303,205,167),(304,206,168),(305,207,168),(306,192,168),(307,208,169),(308,209,169),(309,210,169),(310,211,170),(311,212,170),(312,213,171),(313,214,171),(314,215,171),(315,216,171),(316,217,171),(323,218,172),(324,213,172),(325,222,172),(326,192,173),(327,220,173),(328,221,173),(329,223,173),(330,206,174),(331,192,174),(332,207,174),(333,224,175),(334,225,175),(335,226,175),(336,227,176),(337,228,176),(338,229,176),(339,230,176),(340,231,177),(341,213,177),(342,222,178),(343,232,178);
/*!40000 ALTER TABLE `tb_feed_tag` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:35
