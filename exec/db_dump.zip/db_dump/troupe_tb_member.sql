-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_member`
--

DROP TABLE IF EXISTS `tb_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_member` (
  `member_no` int NOT NULL AUTO_INCREMENT COMMENT '유저번호',
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `nickname` varchar(20) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `member_type` varchar(255) DEFAULT NULL,
  `profile_image_url` varchar(1000) DEFAULT NULL,
  `is_removed` bit(1) DEFAULT b'0',
  `is_authenticated_email` bit(1) DEFAULT b'0',
  `eye_no` int NOT NULL DEFAULT '1',
  `nose_no` int NOT NULL DEFAULT '1',
  `hair_no` int NOT NULL DEFAULT '1',
  `shape_no` int NOT NULL DEFAULT '1',
  `mouth_no` int NOT NULL DEFAULT '1',
  `clothes_no` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`member_no`),
  UNIQUE KEY `member_no_UNIQUE` (`member_no`),
  UNIQUE KEY `nickname_UNIQUE` (`nickname`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `fk_tb_member_tb_character_eye1_idx` (`eye_no`),
  KEY `fk_tb_member_tb_character_nose1_idx` (`nose_no`),
  KEY `fk_tb_member_tb_character_hair1_idx` (`hair_no`),
  KEY `fk_tb_member_tb_character_shape1_idx` (`shape_no`),
  KEY `fk_tb_member_tb_character_mouth1_idx` (`mouth_no`),
  KEY `fk_tb_member_tb_character_clothes1_idx` (`clothes_no`),
  CONSTRAINT `fk_tb_member_tb_character_clothes1` FOREIGN KEY (`clothes_no`) REFERENCES `tb_avatar_clothes` (`clothes_no`),
  CONSTRAINT `fk_tb_member_tb_character_eye1` FOREIGN KEY (`eye_no`) REFERENCES `tb_avatar_eye` (`eye_no`),
  CONSTRAINT `fk_tb_member_tb_character_hair1` FOREIGN KEY (`hair_no`) REFERENCES `tb_avatar_hair` (`hair_no`),
  CONSTRAINT `fk_tb_member_tb_character_mouth1` FOREIGN KEY (`mouth_no`) REFERENCES `tb_avatar_mouth` (`mouth_no`),
  CONSTRAINT `fk_tb_member_tb_character_nose1` FOREIGN KEY (`nose_no`) REFERENCES `tb_avatar_nose` (`nose_no`),
  CONSTRAINT `fk_tb_member_tb_character_shape1` FOREIGN KEY (`shape_no`) REFERENCES `tb_avatar_shape` (`shape_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1835 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_member`
--

LOCK TABLES `tb_member` WRITE;
/*!40000 ALTER TABLE `tb_member` DISABLE KEYS */;
INSERT INTO `tb_member` VALUES (1816,'dyim0403@gmail.com','hello123','도영','안녕하세요','PERFORMER','profile/ce922c93-e2ab-48f6-aeac-45f5a6477619test.png',_binary '\0',_binary '',1,1,11,1,1,2),(1817,'relajar@naver.com','Jj950406!','relajar','안녕하세요:)','PERFORMER','profile/900f3dd5-e598-4232-b46e-9e6a2dd40fa44.jpg',_binary '\0',_binary '',1,1,1,1,1,1),(1818,'tkdfhralsgh@naver.com','123123123','Bnew','SSAFY 7기 공통프로젝트!','PERFORMER','profile/13094c1b-2ca9-40b3-b4d3-9d642d408efd프로필사진.png',_binary '\0',_binary '',3,4,8,1,10,5),(1819,'relajar1@gmail.com','Jj950406!','임재현','안녕하세요오오','PERFORMER','profile/99eda147-964c-4df5-ac94-1cb79d2cfbe1yeslawd.png',_binary '\0',_binary '',3,2,6,1,1,2),(1820,'dlghdwn10@naver.com','12341234','홍홍쥬쥬','이홍주입니다.','PERFORMER','profile/30f593a8-2c5e-48c4-a792-ddea405fb5148.jpg',_binary '\0',_binary '',2,2,4,1,3,4),(1821,'kit938639@gmail.com','chrlghk1!','김인태','김인태 입니다.','PERFORMER','',_binary '\0',_binary '',1,1,1,1,1,1),(1822,'kit3863@naver.com','kit3863@naver.com','insta_z','김인태입니다.','PERFORMER','profile/a0053209-52bd-49b3-b77b-3dc3f7bfd3475.png',_binary '\0',_binary '',2,4,6,1,6,7),(1824,'relajar@skku.edu','Jj950406!','공연덕후123','안녕하신가용','PERFORMER','profile/8ce1b483-9dea-4394-9743-fcdfae234a11기타모양.png',_binary '\0',_binary '',1,1,1,1,1,1),(1832,'fufru@naver.com','12341234','영진코치님','영진코치님입니다.','PERFORMER','profile/8ce1b483-9dea-4394-9743-fcdfae234a11기타모양.png',_binary '\0',_binary '',1,1,1,1,1,1),(1833,'tkdfhrtnalsgh@hanmail.net','123123123','test','test','PERFORMER','',_binary '\0',_binary '',1,1,1,1,1,1),(1834,'crazygun22@gmail.com','12341234','컨설턴트님','컨설턴트님입니다.','PERFORMER','profile/8ce1b483-9dea-4394-9743-fcdfae234a11기타모양.png',_binary '\0',_binary '',1,1,1,1,1,1);
/*!40000 ALTER TABLE `tb_member` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:38
