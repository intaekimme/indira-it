-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_member_guestbook`
--

DROP TABLE IF EXISTS `tb_member_guestbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_member_guestbook` (
  `guestbook_no` int NOT NULL AUTO_INCREMENT COMMENT 'guestbook primary key',
  `host_member_no` int NOT NULL COMMENT '프로필 주인 유저 번호',
  `visitor_member_no` int NOT NULL COMMENT '방문자 유저 번호',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '작성 시간',
  `content` varchar(5000) DEFAULT NULL COMMENT '내용',
  `is_removed` bit(1) DEFAULT b'0' COMMENT '삭제여부',
  PRIMARY KEY (`guestbook_no`),
  KEY `fk_tb_guestbook_tb_user2_idx` (`visitor_member_no`),
  KEY `fk_tb_guestbook_tb_user1` (`host_member_no`),
  CONSTRAINT `fk_tb_guestbook_tb_user1` FOREIGN KEY (`host_member_no`) REFERENCES `tb_member` (`member_no`),
  CONSTRAINT `fk_tb_guestbook_tb_user2` FOREIGN KEY (`visitor_member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_member_guestbook`
--

LOCK TABLES `tb_member_guestbook` WRITE;
/*!40000 ALTER TABLE `tb_member_guestbook` DISABLE KEYS */;
INSERT INTO `tb_member_guestbook` VALUES (180,1816,1816,'2022-08-18 04:38:19','안녕하세요. 임도영입니다.',_binary ''),(181,1820,1820,'2022-08-18 15:52:22','너 짱 오케이~~',_binary ''),(182,1820,1820,'2022-08-18 15:55:56','자~',_binary ''),(183,1820,1820,'2022-08-18 15:56:24','자~',_binary ''),(184,1820,1820,'2022-08-19 02:26:24','오 나야~ ㅎㅎ',_binary '\0');
/*!40000 ALTER TABLE `tb_member_guestbook` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:30
