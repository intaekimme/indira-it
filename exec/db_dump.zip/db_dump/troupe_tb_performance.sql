-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_performance`
--

DROP TABLE IF EXISTS `tb_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_performance` (
  `pf_no` int NOT NULL AUTO_INCREMENT COMMENT '공연번호',
  `member_no` int NOT NULL COMMENT '유저 번호(공연 작성자)',
  `title` varchar(50) NOT NULL COMMENT '공연 이름',
  `location` varchar(50) DEFAULT NULL COMMENT '공연장소',
  `runtime` int DEFAULT NULL COMMENT '총 공연시간',
  `description` varchar(5000) DEFAULT NULL COMMENT '공연 설명 텍스트',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '공연 작성 시간',
  `updated_time` timestamp NULL DEFAULT NULL COMMENT '공연 수정 시간',
  `poster_url` varchar(1000) DEFAULT NULL COMMENT '공연 포스터 url',
  `category_no` int DEFAULT NULL COMMENT '코드 번호(공연 카테고리 테이블)',
  `detail_time` varchar(100) DEFAULT NULL COMMENT '공연 상세 시간',
  `is_removed` bit(1) DEFAULT b'0' COMMENT '삭제 여부',
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pf_no`),
  KEY `fk_tb_performance_tb_user_idx` (`member_no`),
  KEY `fk_tb_performance_tb_category_idx` (`category_no`),
  CONSTRAINT `fk_tb_performance_tb_category` FOREIGN KEY (`category_no`) REFERENCES `tb_category` (`category_no`),
  CONSTRAINT `fk_tb_performance_tb_user` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_performance`
--

LOCK TABLES `tb_performance` WRITE;
/*!40000 ALTER TABLE `tb_performance` DISABLE KEYS */;
INSERT INTO `tb_performance` VALUES (119,1821,'2학기 공통 프로젝트 마무리','멀티캠퍼스',120,'6주간의 여정의 마무리~!','2022-08-17 22:33:13','2022-08-17 22:45:52',NULL,8,NULL,_binary '','2022-08-16 22:32:06','2022-08-22 22:32:06'),(120,1819,'노트르담 드 파리','예술의 전당',140,'프랑스의 소설가 빅토르 위고가 1831년 출간한 장편 소설. 원제는 《노트르담의 곱추》가 아니라 《파리의 노트르담》이다. 《노트르담의 곱추》라는 제목은 영어권에서 The Hunchback of Notre-Dame이라 번역한 것을 중역한 것. 다만 영어권에서도 위고의 소설 《레 미제라블》을 굳이 The miserables로 번역하지 않고 프랑스어 그대로 Les miserables로 사용하는 것처럼, 프랑스어 그대로 Notre-dame de Paris로 사용하기도 한다.','2022-08-17 22:59:26',NULL,'performance/062f8c3e-f985-412f-b583-257fcbc38dc1공연5_사진_1.jpg',2,NULL,_binary '\0','2022-08-23 22:55:33','2022-08-31 22:55:33'),(121,1822,'2학기 공통 프로젝트 발표회','멀티캠퍼스',120,'6주간의 여정의 마무리~!','2022-08-17 23:00:10',NULL,'performance/16c990b2-8baa-47c5-a3a2-99408faf27a8공연_1_사진_3.jpg',8,NULL,_binary '\0','2022-08-22 22:58:34','2022-08-22 22:58:34'),(122,1819,'요한복음','광야아트센터',80,'아-멘','2022-08-17 23:09:13',NULL,'performance/3dfa2d84-4541-4a4f-9d24-d9d58c92bb26공연7_사진_1.jpg',2,NULL,_binary '\0','2022-09-06 23:06:59','2022-09-14 23:06:59'),(123,1822,' 앙상블 콘서트 : Strings Ⅱ​','세종문화회관 체임버홀',120,'작은 앙상블 그러나 큰 감동 쉼이 있는 주말을 위한 특별한 클래식 나들이\r\n\r\n작은 앙상블 그러나 큰 감동! \r\n\"쉼이 있는 주말을 위한 특별한 클래식 나들이\"\r\n\r\n소규모 앙상블의 생생한 감동을 경험할 수 있는 서울시유스오케스트라의 시리즈 공연.\r\n검증된 출연진의 다양한 프로그램 시도를 통한 \r\n현악과 관악의 매력을 발견 할 수 있는 최고의 기회.\r\n가족 친구들과 소중한 일상의 기쁨을 누리는 음악회에 여러분을 초대합니다.','2022-08-17 23:25:51',NULL,'performance/71a0c710-83d8-48d5-868e-7d11dd259a1f공연_2_사진_3.jpg',4,NULL,_binary '\0','2022-08-08 23:20:55','2022-08-29 23:20:55'),(124,1822,' 앙상블 콘서트 : Strings Ⅱ​','세종문화회관 체임버홀',120,'작은 앙상블 그러나 큰 감동 쉼이 있는 주말을 위한 특별한 클래식 나들이\r\n\r\n작은 앙상블 그러나 큰 감동! \r\n\"쉼이 있는 주말을 위한 특별한 클래식 나들이\"\r\n\r\n소규모 앙상블의 생생한 감동을 경험할 수 있는 서울시유스오케스트라의 시리즈 공연.\r\n검증된 출연진의 다양한 프로그램 시도를 통한 \r\n현악과 관악의 매력을 발견 할 수 있는 최고의 기회.\r\n가족 친구들과 소중한 일상의 기쁨을 누리는 음악회에 여러분을 초대합니다.','2022-08-17 23:25:53',NULL,'performance/db866bf1-e5cc-476a-88cb-74261ad4b005공연_2_사진_3.jpg',4,NULL,_binary '','2022-08-08 23:20:55','2022-08-29 23:20:55'),(125,1822,'언더스터디','예술의전당',110,'\"넌 아무 권리도 없어! 넌 그냥 배우야! 아니, 넌 배우도 아니야, 넌 그냥 언더일뿐이야!\"\r\n지극히 평범한 배우이자 아직은 무명인 해리가 미발표된 카프카의 작품에 참여 중인 제이크의 언더스터디로 캐스팅되어 온다. 이 작품의 주인공은 할리우드의 전설적인 탑 배우 부르스가 하차할 수 있는 상황으로 인해 부르스의 언더로 제이크가, 제이크의 언더로 해리가 캐스팅된 상황이다....','2022-08-17 23:36:34','2022-08-17 23:37:36',NULL,1,NULL,_binary '\0','2022-08-01 23:27:58','2022-09-20 23:27:58'),(126,1822,'라이온킹','예술의전당 오페라극장',150,'\"THE KING IS BACK!\" 제왕의 포효가 울린다.','2022-08-17 23:44:17',NULL,'performance/1bdd088d-902f-486b-9669-dbccd34b6c02공연_4_사진_5.jpg',2,NULL,_binary '\0','2022-09-01 23:38:06','2022-09-30 23:38:06'),(127,1819,'This is TVT Club','블루홀',120,'더볼룬티어스 많관부~','2022-08-17 23:47:40',NULL,'performance/7fb0f6d9-7816-4ed1-b674-144cd4bfad31tvt poster.jfif',6,NULL,_binary '\0','2022-08-23 23:46:45','2022-08-28 23:46:45'),(128,1819,'라이프(LIFE) 사진전','한가람미술관',70,'라이프 지 사진의 정수','2022-08-17 23:49:16',NULL,'performance/6fe4fd58-5468-42a1-9400-97927235928a라이프1.jpg',7,NULL,_binary '\0','2022-08-26 23:48:24','2022-12-15 23:48:24'),(129,1819,'라이브 클럽 데이','홍대 일대',300,'라이브 클럽 데이에 여러분을 초대합니다!','2022-08-17 23:51:10',NULL,'performance/a0a26533-8b73-4874-9d00-84a4ad6c4397라클데2.jfif',6,NULL,_binary '\0','2022-08-27 23:50:12','2022-08-27 23:50:12'),(130,1822,'힐링 콘서트 - 역전인디','CATs 사상인디스테이션',70,'도심 속 힐링 콘서트 <역전, 인디!>는 『역전(易傳): 새롭게 바꾸어 전하다 + 인디(indie): 독특한 아이디어와 남들과 차별되는 개성적인 문화코드』의 뜻으로, 지역민들이 스스로 만들어가는 문화로 탈바꿈하여 ‘지역 인디문화의 새로운 변화를 전한다’는 의미를 담고 있다.\r\n','2022-08-17 23:53:27',NULL,'performance/5481e5af-d576-419b-be37-c920aa97d576공연8_사진_2.jpg',6,NULL,_binary '\0','2022-08-23 23:48:52','2022-09-07 23:48:52'),(131,1819,'치즈(CHEEZE) 단독 콘서트','서강대 메리홀',120,'어떻게 생각해!','2022-08-17 23:53:48',NULL,'performance/33a770ff-e966-4557-b29d-532b31b6daf6치즈 라이브.jpg',6,NULL,_binary '\0','2022-08-28 23:52:32','2022-08-28 23:52:32'),(132,1819,'앤더슨팩(Anderson .Paak) 내한 공연','악스홀',100,'YES LAWD!','2022-08-17 23:56:36',NULL,'performance/999216e0-6e93-4405-b97d-31be15d21cf3앤팩.jfif',6,NULL,_binary '\0','2022-11-12 23:55:39','2022-11-13 23:55:39'),(133,1822,'충남대 졸업 전시회','충남대학교',300,'충남대 시각디자인학과 졸업 전시회','2022-08-18 00:00:13',NULL,'performance/5b43f696-ce46-4fd4-957e-f354aa5b656f공연_9_사진_1.png',7,NULL,_binary '\0','2022-08-26 23:54:44','2022-08-29 23:54:44'),(134,1822,'헤어스프레이','충무아트홀',150,'대한민국은 행복한 뚱보, 트레이시의 웃음 바이러스에 빠져든다.\r\n꿈을 이루려는 순수한 열정과 강한 의지, 톡톡 튀는 개성의 행복한 뚱보 트레이시, 사랑과 댄싱퀸 모두를 접수하다.\r\n유쾌함과 경쾌함을 넘어서는 웰메이드 코메디','2022-08-18 00:31:11',NULL,'performance/5e1bbf37-1d47-4a60-97fb-b33fea2443a8헤어스프레이1.JPG',1,NULL,_binary '','2022-08-19 00:30:28','2022-08-31 00:30:28'),(135,1822,'헤어스프레이2222','충무아트홀',150,'대한민국은 행복한 뚱보, 트레이시의 웃음 바이러스에 빠져든다.\r\n꿈을 이루려는 순수한 열정과 강한 의지, 톡톡 튀는 개성의 행복한 뚱보 트레이시, 사랑과 댄싱퀸 모두를 접수하다.\r\n유쾌함과 경쾌함을 넘어서는 웰메이드 코메디','2022-08-18 00:34:46','2022-08-18 00:35:31','performance/1f1f63e0-3dc8-4c85-a1e2-c2a85dfb14ef헤어스프레이1.JPG',1,NULL,_binary '\0','2022-08-19 00:34:10','2022-08-31 00:34:10'),(138,1820,'사진전','',0,'','2022-08-18 16:04:40',NULL,'performance/09c1ab1d-20ae-41c4-82f9-79ddc08e71dd2.jpg',7,NULL,_binary '','2022-08-18 16:04:16','2022-08-20 16:04:16'),(139,1822,'동명대학교 실내건축학과','동명대학교',140,'동명대학교 건축학과 졸업 전시회입니다. \r\n오랜 기간 준비하였습니다. 많이 부족하지만 좋게 봐주셨으면 좋겠습니다.\r\n감사합니다.','2022-08-18 16:42:22',NULL,'performance/69f4bb37-acce-458b-9b73-a1f87e19468c공연_시연_사진_1.gif',7,NULL,_binary '\0','2022-08-01 16:41:38','2022-08-31 16:41:38');
/*!40000 ALTER TABLE `tb_performance` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:36
