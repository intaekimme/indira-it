-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_pf_image`
--

DROP TABLE IF EXISTS `tb_pf_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pf_image` (
  `image_no` int NOT NULL AUTO_INCREMENT COMMENT '상세이미지 번호',
  `pf_no` int NOT NULL,
  `image_url` varchar(1000) DEFAULT NULL COMMENT '상세이미지 url',
  PRIMARY KEY (`image_no`),
  KEY `fk_tb_performance_image_tb_performance1_idx` (`pf_no`),
  CONSTRAINT `fk_tb_performance_image_tb_performance1` FOREIGN KEY (`pf_no`) REFERENCES `tb_performance` (`pf_no`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pf_image`
--

LOCK TABLES `tb_pf_image` WRITE;
/*!40000 ALTER TABLE `tb_pf_image` DISABLE KEYS */;
INSERT INTO `tb_pf_image` VALUES (52,120,'performance/062f8c3e-f985-412f-b583-257fcbc38dc1공연5_사진_1.jpg'),(53,120,'performance/bab2e7a7-25f0-4c33-8c71-42efce833ce5공연5_사진_2.jpg'),(54,120,'performance/1f24497d-303a-4b5a-b465-39cf602e7389공연5_사진_3.jpg'),(55,121,'performance/16c990b2-8baa-47c5-a3a2-99408faf27a8공연_1_사진_3.jpg'),(56,121,'performance/3bf8557e-4bbc-47d6-8619-76c0cc570073공연_1_사진_2.jpg'),(57,121,'performance/b2f3da1a-7aad-4f75-b9b1-9292a5c62061공연_1_사진_1.jpg'),(58,122,'performance/3dfa2d84-4541-4a4f-9d24-d9d58c92bb26공연7_사진_1.jpg'),(59,122,'performance/5a33e3d1-29da-438f-b192-8f0f10795b00공연7_사진_2.jpg'),(60,122,'performance/95ffe5ce-a4ac-4a1d-b73d-bbe31ffb1f77공연7_사진_3.jpg'),(61,123,'performance/71a0c710-83d8-48d5-868e-7d11dd259a1f공연_2_사진_3.jpg'),(62,123,'performance/c3156d0b-12db-4fb1-9d3a-2a13a1094cdc공연_2_사진_2.jpg'),(63,123,'performance/63118c0a-0e6a-42bd-bdc7-f6e6d820b8e6공연_2_사진_1.jpg'),(67,125,'performance/a14f68d6-348c-4214-8f1e-d54f5f6f9331공연_3_사진_3.jpg'),(68,125,'performance/727fc4e6-571d-4134-a1c3-a36573347207공연_3_사진_2.jpg'),(69,125,'performance/108c3f1b-64b5-4efa-9fd1-677feb260c6d공연_3_사진_1.jpg'),(70,126,'performance/1bdd088d-902f-486b-9669-dbccd34b6c02공연_4_사진_5.jpg'),(71,126,'performance/3f8df417-2655-4f83-83a2-8cfc4157c5e0공연_4_사진_4.jpg'),(72,126,'performance/d433b621-263f-42cc-ad53-d6ef341f0d01공연_4_사진_3.jpg'),(73,126,'performance/ebf082ec-cfe2-4f21-9012-121c32dd1670공연_4_사진_2.jpg'),(74,126,'performance/a6fd3b66-8f72-47b9-90e1-7832a7997bd5공연_4_사진_1.jpg'),(75,127,'performance/7fb0f6d9-7816-4ed1-b674-144cd4bfad31tvt poster.jfif'),(76,127,'performance/02ade0a5-baf4-4e59-aff9-437a9b9a583btvt twitter.jfif'),(77,127,'performance/a2e865f6-15f6-4a63-94e2-ce927fac0e6fthis is tvt club.jpg'),(78,128,'performance/6fe4fd58-5468-42a1-9400-97927235928a라이프1.jpg'),(79,128,'performance/84de77c1-d0ef-4288-854d-e627a7486ddc라이프2.jpeg'),(80,128,'performance/ecbfcbd3-935e-4cce-9b67-fdeaed443449라이프3.jpg'),(81,129,'performance/a0a26533-8b73-4874-9d00-84a4ad6c4397라클데2.jfif'),(82,129,'performance/baf34a65-22ea-444c-aecf-d6f165207e77라클데3.jpg'),(83,129,'performance/fb6d60a6-eefd-489c-a69d-c3ca5aaffc37라클데.jfif'),(84,130,'performance/5481e5af-d576-419b-be37-c920aa97d576공연8_사진_2.jpg'),(85,130,'performance/20ca1ee3-5ebd-41b1-95e6-704b7703d2ba공연8_사진_1.jpg'),(86,131,'performance/33a770ff-e966-4557-b29d-532b31b6daf6치즈 라이브.jpg'),(87,131,'performance/ca19ff2f-281f-4207-b3f9-be0a946a11d3치즈.jfif'),(88,131,'performance/a051cffd-7fab-44e0-9188-04036d973cb7치즈치즈.jfif'),(89,132,'performance/999216e0-6e93-4405-b97d-31be15d21cf3앤팩.jfif'),(90,132,'performance/1b83146f-28ec-4c4f-9786-9dff4562085c앤팩2.jfif'),(91,132,'performance/48872792-cd3c-48ec-b149-e6d1a3e5bb8ffree.jpg'),(92,133,'performance/5b43f696-ce46-4fd4-957e-f354aa5b656f공연_9_사진_1.png'),(93,133,'performance/494d68be-5437-491d-abc9-d783b7ca60e6공연_9_사진_2.jpeg'),(94,133,'performance/7f5b6bd9-32ea-4339-893b-ec46e3cbfe8e공연_9_사진_5.jpeg'),(95,133,'performance/96623497-512b-4215-a8f2-ff239b18628c공연_9_사진_4.jpeg'),(96,133,'performance/3dc12882-134e-46c1-8250-f0ac83f96cb6공연_9_사진_3.jpeg'),(107,135,'performance/1f1f63e0-3dc8-4c85-a1e2-c2a85dfb14ef헤어스프레이1.JPG'),(108,135,'performance/71ad1d39-269b-424a-8fe3-c09ed967f0e6헤어스프레이2.JPG'),(109,135,'performance/a7cae24e-5f94-40f9-8f4f-811e2e90fb1b헤어스프레이3.JPG'),(110,135,'performance/f2a7a340-6d35-4f04-94c8-304ed47a096f헤어스프레이4.JPG'),(111,135,'performance/062a9021-d2d6-4142-84f7-83a58d61a0be헤어스프레이5.JPG'),(112,135,'performance/b513ec3f-59a5-4247-ae44-e0fc34e4fa5c헤어스프레이6.JPG'),(117,135,'performance/7a97c803-ca2b-43d3-b4bf-13e5454f7f32공연7_사진_1.jpg'),(118,135,'performance/0260634c-3624-4d34-b184-6e049c3b880b공연7_사진_2.jpg'),(119,135,'performance/cadd0d99-d8fc-41eb-b35c-4792830de380공연7_사진_3.jpg'),(133,139,'performance/69f4bb37-acce-458b-9b73-a1f87e19468c공연_시연_사진_1.gif'),(134,139,'performance/b90b84de-aa81-4b70-9d03-a6d2404caad6공연_시연_사진_2.gif'),(135,139,'performance/e42d14f2-5552-4807-9aa4-458e4884c839공연_시연_사진_3.gif'),(136,139,'performance/17d37d52-5b67-4499-adf6-0589038a546e공연_시연_사진_4.gif');
/*!40000 ALTER TABLE `tb_pf_image` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:39
