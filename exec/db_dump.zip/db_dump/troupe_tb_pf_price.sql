-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_pf_price`
--

DROP TABLE IF EXISTS `tb_pf_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pf_price` (
  `pf_price_no` int NOT NULL AUTO_INCREMENT,
  `pf_no` int NOT NULL,
  `seat` varchar(10) NOT NULL COMMENT '좌석',
  `price` int DEFAULT NULL COMMENT '가격',
  PRIMARY KEY (`pf_price_no`),
  KEY `fk_tb_performance_price_tb_performance1_idx` (`pf_no`),
  CONSTRAINT `fk_tb_performance_price_tb_performance1` FOREIGN KEY (`pf_no`) REFERENCES `tb_performance` (`pf_no`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pf_price`
--

LOCK TABLES `tb_pf_price` WRITE;
/*!40000 ALTER TABLE `tb_pf_price` DISABLE KEYS */;
INSERT INTO `tb_pf_price` VALUES (139,120,'S석',100000),(140,120,'R석',300000),(141,121,'R',10000),(142,121,'S',5000),(143,122,'전석',55000),(144,123,'R',25000),(145,123,'S',20000),(150,125,'R',30000),(151,125,'S',25000),(152,126,'R',55000),(153,126,'S',45000),(154,126,'A',40000),(155,127,'스탠딩',80000),(156,128,'입장료',20000),(157,129,'스탠딩',45000),(158,130,'R',15000),(159,130,'S',10000),(160,131,'스탠딩석',88000),(161,131,'좌석',55000),(162,132,'스탠딩',110000),(163,133,'R',0),(168,135,'R',20000),(169,135,'S',10000),(170,135,'A',5000),(176,139,'R',-1);
/*!40000 ALTER TABLE `tb_pf_price` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:33
