-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_pf_save`
--

DROP TABLE IF EXISTS `tb_pf_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pf_save` (
  `pf_save_no` int NOT NULL AUTO_INCREMENT,
  `member_no` int NOT NULL COMMENT '유저 번호',
  `pf_no` int NOT NULL COMMENT '공연 번호',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '저장한 시각',
  `is_removed` bit(1) DEFAULT b'0' COMMENT '삭제여부',
  PRIMARY KEY (`pf_save_no`),
  KEY `fk_tb_performance_saved_tb_performance1_idx` (`pf_no`),
  KEY `fk_tb_performance_saved_tb_user1` (`member_no`),
  CONSTRAINT `fk_tb_performance_saved_tb_performance1` FOREIGN KEY (`pf_no`) REFERENCES `tb_performance` (`pf_no`),
  CONSTRAINT `fk_tb_performance_saved_tb_user1` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pf_save`
--

LOCK TABLES `tb_pf_save` WRITE;
/*!40000 ALTER TABLE `tb_pf_save` DISABLE KEYS */;
INSERT INTO `tb_pf_save` VALUES (52,1824,122,'2022-08-17 23:22:55',_binary '\0'),(53,1824,121,'2022-08-17 23:22:56',_binary '\0'),(54,1824,120,'2022-08-17 23:22:56',_binary '\0'),(55,1820,129,'2022-08-17 23:54:47',_binary ''),(56,1820,128,'2022-08-17 23:54:46',_binary ''),(57,1820,127,'2022-08-17 23:54:46',_binary ''),(58,1820,131,'2022-08-18 13:56:02',_binary ''),(59,1820,130,'2022-08-17 23:54:55',_binary '\0'),(60,1822,132,'2022-08-18 03:03:16',_binary '\0'),(61,1822,128,'2022-08-18 03:02:57',_binary ''),(62,1822,127,'2022-08-18 03:02:55',_binary ''),(63,1819,130,'2022-08-18 00:23:08',_binary '\0'),(64,1819,132,'2022-08-18 00:23:09',_binary '\0'),(65,1819,131,'2022-08-18 00:23:10',_binary '\0'),(66,1819,126,'2022-08-18 00:23:13',_binary '\0'),(67,1819,123,'2022-08-18 00:23:14',_binary '\0'),(68,1819,122,'2022-08-18 00:24:24',_binary '\0'),(69,1819,121,'2022-08-18 00:24:25',_binary '\0'),(70,1819,120,'2022-08-18 00:24:30',_binary '\0'),(71,1822,135,'2022-08-18 03:03:15',_binary '\0'),(72,1822,131,'2022-08-18 03:03:09',_binary ''),(73,1822,130,'2022-08-18 03:03:08',_binary ''),(74,1820,123,'2022-08-18 01:15:26',_binary '\0'),(75,1822,129,'2022-08-18 03:03:18',_binary '\0'),(76,1822,123,'2022-08-18 11:47:19',_binary '\0'),(77,1816,123,'2022-08-18 15:55:15',_binary '\0'),(78,1816,131,'2022-08-18 15:55:33',_binary '\0'),(79,1816,133,'2022-08-18 15:55:38',_binary '\0'),(80,1822,139,'2022-08-18 16:42:36',_binary '\0'),(81,1822,133,'2022-08-18 16:42:37',_binary '\0'),(82,1820,139,'2022-08-18 17:19:20',_binary '\0');
/*!40000 ALTER TABLE `tb_pf_save` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-18 17:31:37
