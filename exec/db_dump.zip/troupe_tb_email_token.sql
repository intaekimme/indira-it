-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_email_token`
--

DROP TABLE IF EXISTS `tb_email_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_email_token` (
  `token` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `is_expired` bit(1) DEFAULT NULL,
  `expiration_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_email_token`
--

LOCK TABLES `tb_email_token` WRITE;
/*!40000 ALTER TABLE `tb_email_token` DISABLE KEYS */;
INSERT INTO `tb_email_token` VALUES ('1435dcd1-a5e0-4163-86b5-e6fb839a5b8e','tkdfhrtnalsgh@hanmail.net',_binary '','2022-08-18 01:18:29'),('4943c68f-52e3-4e3d-93eb-d12490377257','tommy7899@naver.com',_binary '','2022-08-18 16:45:36'),('59e253bd-56e5-4fd2-b3ba-660b826f9fef','tkdfhralsgh@naver.com',_binary '\0','2022-08-17 19:49:48'),('5a39d978-0163-45b8-ace3-17050ea31c54','relajar1@gmail.com',_binary '','2022-08-17 19:54:23'),('64f4bc1b-dafa-4bc6-8844-0160168e8024','tkdfhralsgh@naver.com',_binary '','2022-08-17 19:48:43'),('700f3029-f656-4d18-be0d-48bbce5c334e','kit3863@naver.com',_binary '','2022-08-17 23:06:05'),('7c76d86b-825e-4223-8189-2e9430bca22c','dyim0403@gmail.com',_binary '','2022-08-17 16:07:13'),('81669d5f-0a2d-4ca2-a5c7-9d8d67c6c73c','relajar@naver.com',_binary '','2022-08-17 18:51:21'),('82935ec3-6e3c-42ab-a60d-c3184f6200ce','dyim0403@gmail.com',_binary '\0','2022-08-17 19:12:38'),('89411481-52b7-419e-9d91-fecff7f8bcad','tkdfhrtnalsgh@hanmail.net',_binary '','2022-08-18 01:17:54'),('915776f3-20bf-4539-acf6-12dc513ed4b3','dlghdwn10@naver.com',_binary '','2022-08-17 20:49:59'),('926c38ab-8541-4ac4-a32f-20264bed5e8f','tkdfhralsgh@naver.com',_binary '','2022-08-17 19:50:46'),('b26e2329-e780-4267-9fa4-eae9b5e5346e','tkdfhralsgh@naver.com',_binary '','2022-08-17 19:55:04'),('b71fdd6e-2a2e-4ef6-8f49-96d6c8740cd3','tkdfhralsgh@naver.com',_binary '','2022-08-17 19:53:52'),('b89d6542-c3df-4e0b-a112-ac31a45f290d','dyim0403@gmail.com',_binary '','2022-08-17 19:50:23'),('d19fdd2f-e389-469b-8072-dc738447a983','tkdfhrtnalsgh@hanmail.net',_binary '','2022-08-18 18:22:52'),('d3fbb883-9741-4e2b-9469-c2748708dafa','kit938639@gmail.com',_binary '','2022-08-17 21:29:30'),('e900e794-4ef8-4fc0-af95-b332e47440c3','relajar@skku.edu',_binary '','2022-08-17 23:31:31');
/*!40000 ALTER TABLE `tb_email_token` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  2:21:28
