-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_feed`
--

DROP TABLE IF EXISTS `tb_feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_feed` (
  `feed_no` int NOT NULL AUTO_INCREMENT COMMENT '피드 번호',
  `member_no` int NOT NULL,
  `content` varchar(500) DEFAULT NULL COMMENT '피드 내용',
  `is_removed` bit(1) DEFAULT b'0' COMMENT '삭제 여부',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`feed_no`),
  KEY `fk_tb_feed_tb_user1_idx` (`member_no`),
  CONSTRAINT `fk_tb_feed_tb_user1` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_feed`
--

LOCK TABLES `tb_feed` WRITE;
/*!40000 ALTER TABLE `tb_feed` DISABLE KEYS */;
INSERT INTO `tb_feed` VALUES (162,1816,'안녕하세요~~',_binary '\0','2022-08-18 01:56:43'),(163,1817,'첫 공연날:)',_binary '\0','2022-08-18 03:50:57'),(164,1817,'까데호X넉살 당신께 많관부~',_binary '\0','2022-08-18 04:22:09'),(165,1819,'백예린 많관부~',_binary '\0','2022-08-18 04:50:02'),(166,1819,'햄릿 마지막 결투 장면~',_binary '\0','2022-08-18 04:53:05'),(167,1819,'좋아하는 것들',_binary '\0','2022-08-18 04:54:12'),(168,1819,'적재 쵝오',_binary '','2022-08-18 04:55:06'),(169,1819,'라이프 지 사진전',_binary '\0','2022-08-18 04:56:53'),(170,1819,'백조의 호수',_binary '\0','2022-08-18 04:57:23'),(171,1819,'미스사이공',_binary '\0','2022-08-18 04:58:06'),(172,1819,'캣츠 너무 재밌었다!',_binary '\0','2022-08-18 05:42:22'),(173,1819,'너무나도 감동적이었던 라이브 공연!',_binary '\0','2022-08-18 05:47:09'),(174,1819,'적재 라이브 많이 보러 와주세요:)',_binary '\0','2022-08-18 06:12:09'),(175,1820,'내가 좋아하는 풍경들... 같이 공유하고 싶네요..^^',_binary '','2022-08-18 08:58:37'),(176,1822,'ㅇㅇ대 시각디자인과 졸업전시회',_binary '\0','2022-08-18 11:21:29'),(177,1822,'헤어스프레이 소감',_binary '\0','2022-08-18 14:55:22'),(178,1820,'냐옹~~',_binary '\0','2022-08-18 15:45:39'),(179,1819,'여러분들 덕분에 집샀어요~~모두모두 감사합니다(〃´?`〃)(〃´?`〃)',_binary '\0','2022-08-18 22:02:39'),(180,1822,'역시 음악을 롹이쥐~????????',_binary '\0','2022-08-18 22:43:08'),(181,1816,'난 위너 좋아해.. 너는 루저?',_binary '\0','2022-08-18 23:10:59'),(182,1819,'R&B 송라이터 죠지는 싱글 보트의 중독성 있는 후렴구와 유쾌한 모습이 담긴 뮤직비디오를 통해 리스너들의 주목을 받았다. 이후 꾸준히 싱글과 EP를 발표하면서 죠지만의 뚜렷한 음색과 음악적 역량을 선보였고, 아도이, 김현철 등 다양한 아티스트와의 협업으로 존재감을 보여주었다. 최근 딩고와 콜라보레이션 한 싱글 ‘camping everywhere’를 발표하며 대세임을 입증하기도 하였다.',_binary '\0','2022-08-19 08:56:11'),(183,1820,'피드등록합니다~!~!피드등록합니다~!~!피드등록합니다~!~!피드등록합니다~!~!',_binary '\0','2022-08-19 01:13:44'),(184,1820,'피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!피드등록~!',_binary '\0','2022-08-19 01:22:22');
/*!40000 ALTER TABLE `tb_feed` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  2:21:29
