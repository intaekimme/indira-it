-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_pf_review`
--

DROP TABLE IF EXISTS `tb_pf_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pf_review` (
  `review_no` int NOT NULL AUTO_INCREMENT COMMENT '후기 번호',
  `pf_no` int NOT NULL COMMENT '공연 번호',
  `member_no` int NOT NULL COMMENT '유저 번호',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '작성 시간',
  `is_modified` bit(1) DEFAULT NULL COMMENT '수정 여부',
  `is_removed` bit(1) DEFAULT NULL COMMENT '삭제 여부',
  `content` varchar(5000) DEFAULT NULL COMMENT '내용',
  `parent_review_no` int DEFAULT NULL COMMENT '부모 후기 번호',
  PRIMARY KEY (`review_no`),
  KEY `fk_tb_performance_review_tb_performance1_idx` (`pf_no`),
  KEY `fk_tb_performance_review_tb_user1_idx` (`member_no`),
  KEY `fk_tb_pf_review_tb_pf_review_idx` (`parent_review_no`),
  CONSTRAINT `fk_tb_pf_review_tb_member` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`),
  CONSTRAINT `fk_tb_pf_review_tb_performance` FOREIGN KEY (`pf_no`) REFERENCES `tb_performance` (`pf_no`),
  CONSTRAINT `fk_tb_pf_review_tb_pf_review` FOREIGN KEY (`parent_review_no`) REFERENCES `tb_pf_review` (`review_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3156 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pf_review`
--

LOCK TABLES `tb_pf_review` WRITE;
/*!40000 ALTER TABLE `tb_pf_review` DISABLE KEYS */;
INSERT INTO `tb_pf_review` VALUES (3109,132,1822,'2022-08-18 00:22:32',_binary '',_binary '\0','우와 너무 보고 싶은 공연이에요!!!!!',NULL),(3110,132,1822,'2022-08-18 00:22:41',_binary '\0',_binary '','정말 기대가 됩니다!',NULL),(3112,131,1820,'2022-08-18 13:56:15',_binary '\0',_binary '','재밌을거 같아요!!',NULL),(3113,131,1820,'2022-08-18 13:58:23',_binary '',_binary '','하하아닙니다',3112),(3114,123,1822,'2022-08-18 16:41:26',_binary '\0',_binary '\0','안녕하세요',NULL),(3115,123,1816,'2022-08-18 20:18:47',_binary '\0',_binary '\0','너무 좋았어요~~',NULL),(3116,131,1816,'2022-08-18 20:19:42',_binary '\0',_binary '\0','콘서트 기대됩니다',NULL),(3117,121,1816,'2022-08-18 20:21:04',_binary '',_binary '\0','재밌겠네요',NULL),(3118,123,1820,'2022-08-18 20:25:53',_binary '\0',_binary '\0','최고예요',NULL),(3119,123,1819,'2022-08-18 20:26:50',_binary '\0',_binary '\0','저도요~',3115),(3120,123,1822,'2022-08-18 20:27:35',_binary '\0',_binary '\0','감사합니다!',3115),(3121,123,1822,'2022-08-18 20:27:47',_binary '\0',_binary '\0','감사합니다!',3118),(3122,123,1820,'2022-08-18 20:28:23',_binary '\0',_binary '\0','안녕하세요',3114),(3123,121,1820,'2022-08-18 20:29:03',_binary '\0',_binary '\0','프로젝트 끝~~',NULL),(3124,130,1820,'2022-08-18 20:29:47',_binary '\0',_binary '\0','힐링 좋아요',NULL),(3125,139,1816,'2022-08-18 20:32:41',_binary '\0',_binary '\0','보러갈게요~',NULL),(3126,142,1819,'2022-08-18 22:08:19',_binary '\0',_binary '\0','많이 보러와주세요~~!~! ՞‪⸝⸝> ̫ <⸝⸝՞',NULL),(3127,140,1819,'2022-08-18 22:17:08',_binary '',_binary '\0','??내가 사준 피아노~ 잘쓰고 있나요오~!~!',NULL),(3128,145,1819,'2022-08-18 22:20:56',_binary '\0',_binary '\0','진짜 재밌는데..?ྀི?ྀི?ྀི?ྀི?ྀི?ྀི',NULL),(3129,141,1819,'2022-08-18 22:21:54',_binary '\0',_binary '\0','고래 좋아...╭◜◝ ͡  ◜◝ (      ´ㅅ` ) ╰◟◞  ͜     둥실.╭◜◝ ͡  ◜◝ (      ´ㅅ` ) ╰◟◞  ͜     둥실',NULL),(3130,141,1820,'2022-08-18 22:22:35',_binary '\0',_binary '\0','저도요..＼?へ　 へ?ヘ　 く?/ ',3129),(3131,146,1820,'2022-08-18 22:25:03',_binary '\0',_binary '\0','제가 만든 포스터...???',NULL),(3132,147,1820,'2022-08-18 23:00:42',_binary '\0',_binary '\0','웅성???뭐야..???????? ????????? 뭐야..??????????????????? 뭐야..??? ?????????????????웅성웅성..?? ??????????? ??????????? ????뭐야..??????? ????????? ??웅성..????????? ???????? 뭐야..??? ???????? ?',NULL),(3133,123,1820,'2022-08-18 23:00:59',_binary '\0',_binary '\0','웅성???뭐야..???????? ????????? 뭐야..??????????????????? 뭐야..??? ?????????????????웅성웅성..?? ??????????? ??????????? ????뭐야..??????? ????????? ??웅성..????????? ???????? 뭐야..??? ???????? ?',NULL),(3134,141,1820,'2022-08-18 23:04:41',_binary '\0',_binary '\0','이 사건은 재미있습니다? 제가 좋아하는?고래?퀴즈❓같아요. 몸무게가?️ 22톤인 암컷 향고래가 500kg에 달하는 대왕오징어를? 먹고 ? 6시간 뒤 1.3톤짜리 알을?낳았다면 이 암컷 향고래의 몸무게는?️얼마일까요? (모르겠어요.) 정답은 \'고래는? 알을?낳을 수 없다❌\'입니다. 고래는?포유류라 알이?아닌❌새끼를? 낳으니까요. 무게에만 초점을?맞추면 문제를 풀 수 없습니다.❌핵심을 봐야?돼요. (예, 그래서요?) 이 사건은 형사사건이니까, 사람들은 보통 형법에만 초점을?맞출 겁니다. 하지만?그러면 답이 안❌보여요?핵심은?민법에 있습니다. (민법?) 민법 1004조 \'고의로 직계 존속, 피상속인 그 배우자?‍❤️‍?‍?또는 상속의 선순위나?동순위에 있는 자를 살해하거나?살해하려는?자는 상속을 받을 수 없다.\' 다시 말해 자기가 죽이거나?죽이려고한?사람한테서는 상속을 받을 수 없다는❌뜻입니다. 피고인은 퇴직 공무원인 남편의?연금으로 생활합니다. 임대료를 받는?다세대 주택도 남편 명의입니다. 만약 살인 미수죄가?인정된다면, 피고인은 남편이 죽고 난 뒤?엄청난 경제적?위기에?처하게 됩니다?',NULL),(3135,139,1820,'2022-08-18 23:05:06',_binary '\0',_binary '\0','저는 안볼래요',NULL),(3136,125,1820,'2022-08-18 23:05:36',_binary '\0',_binary '\0','공연 추카해 ~~ ????????????????????????????',NULL),(3137,142,1816,'2022-08-18 23:10:04',_binary '\0',_binary '\0','네~~',3126),(3138,126,1816,'2022-08-18 23:10:49',_binary '',_binary '\0','와 사자다! ???',NULL),(3139,145,1816,'2022-08-18 23:12:01',_binary '\0',_binary '\0','???',3128),(3140,140,1816,'2022-08-18 23:12:16',_binary '\0',_binary '\0','',3127),(3141,133,1816,'2022-08-18 23:14:12',_binary '\0',_binary '\0','벌써 졸업이라니~~',NULL),(3142,147,1816,'2022-08-18 23:16:24',_binary '\0',_binary '\0','메탈은 금속~~~',NULL),(3143,143,1816,'2022-08-18 23:19:06',_binary '\0',_binary '\0','코로나 조심하기!! ',NULL),(3144,145,1816,'2022-08-18 23:19:20',_binary '',_binary '\0','음악 좋아요~~~ ???????????',NULL),(3145,141,1816,'2022-08-18 23:19:47',_binary '\0',_binary '\0','??????????',3129),(3146,141,1816,'2022-08-18 23:19:50',_binary '\0',_binary '\0','??????????????',NULL),(3147,141,1816,'2022-08-18 23:20:12',_binary '\0',_binary '\0','우tothe영tothe우..??????????',3134),(3148,125,1816,'2022-08-18 23:22:32',_binary '\0',_binary '\0','*.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.*',NULL),(3149,125,1816,'2022-08-18 23:22:37',_binary '\0',_binary '\0','*.☆⸜(⑉˙ᗜ˙⑉)⸝♡.**.☆⸜(⑉˙ᗜ˙⑉)⸝♡.*',3136),(3150,140,1816,'2022-08-18 23:22:53',_binary '\0',_binary '\0','(*ˊᵕˋo?o(*ˊᵕˋo?o(*ˊᵕˋo?o(*ˊᵕˋo?o(*ˊᵕˋo?o(*ˊᵕˋo?o(*ˊᵕˋo?o',NULL),(3151,144,1816,'2022-08-18 23:23:24',_binary '\0',_binary '\0','소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)소은 좋아(˵⚈ε⚈˵)',NULL),(3152,135,1816,'2022-08-18 23:23:48',_binary '\0',_binary '\0','(❁´▽`❁)*✲ﾟ*(❁´▽`❁)*✲ﾟ*(❁´▽`❁)*✲ﾟ*(❁´▽`❁)*✲ﾟ*(❁´▽`❁)*✲ﾟ*이거 진짜 재밌더라..',NULL),(3153,129,1816,'2022-08-18 23:24:12',_binary '\0',_binary '\0','화질 자비좀요...ㅋㅋㅋ..ㅋ화질 자비좀요...ㅋㅋㅋ..ㅋ화질 자비좀요...ㅋㅋㅋ..ㅋ화질 자비좀요...ㅋㅋㅋ..ㅋ화질 자비좀요...ㅋㅋㅋ..ㅋ화질 자비좀요...ㅋㅋㅋ..ㅋ',NULL),(3154,121,1816,'2022-08-18 23:24:50',_binary '\0',_binary '\0','아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)아닌데?(•⚗৺⚗•)',3123),(3155,127,1816,'2022-08-18 23:26:28',_binary '\0',_binary '\0','하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و하이팅!!(๑•̀ㅂ•́)و',NULL);
/*!40000 ALTER TABLE `tb_pf_review` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  2:21:29
