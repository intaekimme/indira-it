-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: troupe.cvg3ycl5pbuo.ap-northeast-2.rds.amazonaws.com    Database: troupe
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `tb_pf_save`
--

DROP TABLE IF EXISTS `tb_pf_save`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_pf_save` (
  `pf_save_no` int NOT NULL AUTO_INCREMENT,
  `member_no` int NOT NULL COMMENT '유저 번호',
  `pf_no` int NOT NULL COMMENT '공연 번호',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '저장한 시각',
  `is_removed` bit(1) DEFAULT b'0' COMMENT '삭제여부',
  PRIMARY KEY (`pf_save_no`),
  KEY `fk_tb_performance_saved_tb_performance1_idx` (`pf_no`),
  KEY `fk_tb_performance_saved_tb_user1` (`member_no`),
  CONSTRAINT `fk_tb_performance_saved_tb_performance1` FOREIGN KEY (`pf_no`) REFERENCES `tb_performance` (`pf_no`),
  CONSTRAINT `fk_tb_performance_saved_tb_user1` FOREIGN KEY (`member_no`) REFERENCES `tb_member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pf_save`
--

LOCK TABLES `tb_pf_save` WRITE;
/*!40000 ALTER TABLE `tb_pf_save` DISABLE KEYS */;
INSERT INTO `tb_pf_save` VALUES (52,1824,122,'2022-08-17 23:22:55',_binary '\0'),(53,1824,121,'2022-08-17 23:22:56',_binary '\0'),(54,1824,120,'2022-08-17 23:22:56',_binary '\0'),(55,1820,129,'2022-08-18 21:58:16',_binary '\0'),(56,1820,128,'2022-08-18 21:58:13',_binary '\0'),(57,1820,127,'2022-08-18 21:58:13',_binary '\0'),(58,1820,131,'2022-08-18 21:58:15',_binary '\0'),(59,1820,130,'2022-08-17 23:54:55',_binary '\0'),(60,1822,132,'2022-08-18 03:03:16',_binary '\0'),(61,1822,128,'2022-08-18 03:02:57',_binary ''),(62,1822,127,'2022-08-18 03:02:55',_binary ''),(63,1819,130,'2022-08-19 00:11:03',_binary '\0'),(64,1819,132,'2022-08-19 00:09:47',_binary ''),(65,1819,131,'2022-08-19 00:09:48',_binary ''),(66,1819,126,'2022-08-19 00:09:51',_binary ''),(67,1819,123,'2022-08-19 00:10:57',_binary '\0'),(68,1819,122,'2022-08-19 00:09:49',_binary ''),(69,1819,121,'2022-08-19 00:10:14',_binary '\0'),(70,1819,120,'2022-08-19 00:11:02',_binary '\0'),(71,1822,135,'2022-08-18 03:03:15',_binary '\0'),(72,1822,131,'2022-08-18 20:23:48',_binary '\0'),(73,1822,130,'2022-08-18 20:23:49',_binary '\0'),(74,1820,123,'2022-08-18 01:15:26',_binary '\0'),(75,1822,129,'2022-08-18 03:03:18',_binary '\0'),(76,1822,123,'2022-08-18 11:47:19',_binary '\0'),(77,1816,123,'2022-08-18 15:55:15',_binary '\0'),(78,1816,131,'2022-08-18 15:55:33',_binary '\0'),(79,1816,133,'2022-08-18 15:55:38',_binary '\0'),(80,1822,139,'2022-08-18 16:42:36',_binary '\0'),(81,1822,133,'2022-08-18 16:42:37',_binary '\0'),(82,1820,139,'2022-08-18 17:19:20',_binary '\0'),(83,1816,139,'2022-08-18 20:15:01',_binary '\0'),(84,1816,125,'2022-08-18 20:15:02',_binary '\0'),(85,1816,135,'2022-08-18 20:15:03',_binary '\0'),(86,1816,127,'2022-08-18 20:15:04',_binary '\0'),(87,1816,130,'2022-08-18 20:15:04',_binary '\0'),(88,1816,121,'2022-08-18 20:15:05',_binary '\0'),(89,1816,120,'2022-08-18 20:15:05',_binary '\0'),(90,1816,128,'2022-08-18 20:15:06',_binary '\0'),(91,1816,129,'2022-08-18 20:15:08',_binary '\0'),(92,1816,122,'2022-08-18 20:15:09',_binary '\0'),(93,1816,126,'2022-08-18 20:15:10',_binary '\0'),(94,1816,132,'2022-08-18 20:15:10',_binary '\0'),(95,1822,126,'2022-08-18 20:23:47',_binary '\0'),(96,1824,130,'2022-08-18 20:24:19',_binary '\0'),(97,1820,120,'2022-08-18 21:58:11',_binary '\0'),(98,1820,122,'2022-08-18 21:58:14',_binary '\0'),(99,1820,132,'2022-08-18 21:58:17',_binary '\0'),(100,1820,121,'2022-08-18 22:29:48',_binary '\0'),(101,1820,126,'2022-08-18 22:29:49',_binary '\0'),(102,1820,144,'2022-08-18 22:30:07',_binary '\0'),(103,1820,142,'2022-08-18 22:30:08',_binary '\0'),(104,1820,145,'2022-08-18 22:30:09',_binary '\0'),(105,1820,143,'2022-08-18 22:30:10',_binary '\0'),(106,1820,133,'2022-08-18 22:48:43',_binary '\0'),(107,1820,125,'2022-08-18 23:00:20',_binary '\0'),(108,1820,135,'2022-08-18 23:00:21',_binary '\0'),(109,1820,147,'2022-08-18 23:00:23',_binary '\0'),(110,1820,141,'2022-08-18 23:03:28',_binary '\0'),(111,1820,140,'2022-08-18 23:03:28',_binary '\0'),(112,1816,140,'2022-08-18 23:09:56',_binary '\0'),(113,1816,141,'2022-08-18 23:09:57',_binary '\0'),(114,1816,144,'2022-08-18 23:16:31',_binary '\0'),(115,1816,142,'2022-08-18 23:16:32',_binary '\0'),(116,1816,143,'2022-08-18 23:16:34',_binary '\0'),(117,1816,145,'2022-08-18 23:16:34',_binary '\0'),(118,1819,144,'2022-08-19 00:10:18',_binary '\0'),(119,1819,149,'2022-08-19 00:10:14',_binary '\0'),(120,1819,150,'2022-08-19 00:10:12',_binary '\0'),(121,1819,145,'2022-08-19 00:10:13',_binary '\0'),(122,1819,125,'2022-08-19 00:10:57',_binary '\0'),(123,1819,140,'2022-08-19 00:10:17',_binary '\0'),(124,1819,135,'2022-08-19 00:10:21',_binary '\0'),(125,1819,139,'2022-08-19 00:10:58',_binary '\0'),(126,1819,141,'2022-08-19 00:10:59',_binary '\0'),(127,1819,127,'2022-08-19 00:11:03',_binary '\0'),(128,1819,128,'2022-08-19 00:11:04',_binary '\0'),(129,1819,142,'2022-08-19 00:11:05',_binary '\0'),(130,1819,148,'2022-08-19 00:11:05',_binary '\0'),(131,1819,143,'2022-08-19 00:11:07',_binary '\0');
/*!40000 ALTER TABLE `tb_pf_save` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  2:21:26
